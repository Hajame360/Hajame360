// Question 1
// create a loop 1. program to print table of 5 eg 5, 10 , 15 etc

var num=0;

while(num<=50)
{
    console.log(num);
    num+=5;
}




// Question 2
//2. variables holding marks of 5 subjects/ calculate the percentage and give grades


var mathematics=100;

if(mathematics>=75 && mathematics<=100)
{
    console.log("Mathematics        Distinction");
}
else if(mathematics>=65 && mathematics<=74)
{
    console.log("Mathematics        Merit");
}

else if(mathematics>=55 && mathematics<=64)
{
    console.log("Mathematics        Credit");
}
else if(mathematics>=40 && mathematics<=54)
{
    console.log("Mathematics        Pass");
}
else if(mathematics<=39)
{
    console.log("Mathematics        Fail");
}






var science=70;

if(science>=75 && science<=100)
{
    console.log("Science            Distinction");
}
else if(science>=65 && science<=74)
{
    console.log("Science            Merit");
}

else if(science>=55 && science<=64)
{
    console.log("Science            Credit");
}
else if(science>=40 && science<=54)
{
    console.log("Science            Pass");
}
else if(science<=39)
{
    console.log("Science            Fail");
}






var english=56;

if(english>=75 && english<=100)
{
    console.log("English            Distinction");
}
else if(english>=65 && english<=74)
{
    console.log("English            Merit");
}
else if(english>=55 && english<=64)
{
    console.log("English            Credit");
}
else if(english>=40 && english<=54)
{
    console.log("English            Pass");
}
else if(english<=39)
{
    console.log("English            Fail");
}



var geography=29;

if(geography>=75 && geography<=100)
{
    console.log("Geography          Distinction");
}
else if(geography>=65 && geography<=74)
{
    console.log("Geography          Merit");
}
else if(geography>=55 && geography<=64)
{
    console.log("Geography          Credit");
}
else if(geography>=40 &&geography<=54)
{
    console.log("Geography          Pass");
}
else if(geography<=39)
{
    console.log("Geography          Fail");
}




var computer=40;

if(computer>=75 && computer<=100)
{
    console.log("Computer           Distinction");
}
else if(computer>=65 && computer<=74)
{
    console.log("Computer           Merit");
}
else if(computer>=55 && computer<=64)
{
    console.log("Computer           Credit");
}
else if(computer>=40 && computer<=54)
{
    console.log("Computer           Pass");
}
else if(computer<=39)
{
    console.log("Computer           Fail");
}